package com.example.greengrocer

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
