import 'package:http/http.dart' as http;

import '../http_service.dart';

class HttpClient implements IHttpClient {
  final client = http.Client();

  @override
  Future get({required String url, Map<String, String>? headers}) async {
    return await client.get(
      Uri.parse(url),
      headers: headers,
    );
  }

  @override
  Future? post({required String url, required dynamic body, Map<String, String>? headers}) async {
    return await client.post(
      Uri.parse(url),
      body: body,
      headers: headers,
    );
  }
}
