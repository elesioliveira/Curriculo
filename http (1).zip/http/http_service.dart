abstract interface class IHttpClient {
  Future? get({required String url, Map<String, String>? headers});

  Future? post({required String url, required dynamic body, required Map<String, String> headers});
}
